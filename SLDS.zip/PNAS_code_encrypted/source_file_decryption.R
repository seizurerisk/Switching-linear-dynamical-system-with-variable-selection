library(encryptr)

# First, request the decryption password by following instructions in the README.
# Then execute the below code, entering password when prompted.

decrypt_file('NBSLDS.R.encryptr.bin', 'NBSLDS.R')
