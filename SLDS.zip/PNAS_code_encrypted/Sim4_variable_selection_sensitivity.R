# This file reproduces the sensitivity analysis results corresponding to 
# Appendix B.4 of the supplement. Different beta hyperpriors on the latent
# latent inclusion indicators were investigated for effect on variable
# selection performance. 

# Simulation --------------------------------------------------------------

library(doSNOW)
library(parallel)
library(truncnorm)
library(BayesLogit)
library(mvtnorm)
library(MCMCpack)
library(knitr)
library(gtools)
library(abind)
library(MASS)
library(coda)
library(ZIM)
library(Rcpp)
library(matrixcalc)
library(matrixStats)

c1 <- makeCluster(24)
registerDoSNOW(c1)

source('NBSLDS.R')

seed_store = rep(1:24, 5)
sims = length(seed_store)
g_rho_store = c(rep(1,24), rep(2,24), rep(1,24), rep(1,24), rep(1,24))
h_rho_store = c(rep(1,24), rep(3,24), rep(2,24), rep(3,24), rep(5,24))

myresults <- foreach(current_sim = 1:sims, .packages = c('doSNOW','truncnorm','BayesLogit','mvtnorm','MCMCpack', 'matrixcalc','matrixStats'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE) %dopar% { 
                       
                       # Data generation
                       set.seed(seed_store[current_sim])
                       run.mc.sim <- function(A, num.iters = 50) {
                         num.states <- nrow(A)
                         states <- numeric(num.iters)
                         states[1] <- sample(1:2, 1, prob = c(0.5, 0.5))
                         for(t in 2:num.iters) {
                           p  <- A[states[t-1],]
                           states[t] <-  which(rmultinom(1, 1, p) == 1)
                         }
                         return(states)
                       }
                       
                       A = matrix(data = c(0.98, 0.02, 0.02, 0.98), byrow = TRUE, nrow = 2, ncol = 2)
                       Ti = 2000
                       p = 7
                       
                       # Parameters
                       maxiter = 20000
                       burnin = 10000
                       J = 10
                       r = c(2,5)
                       lambda = c(-1.5,-0.5)
                       sigma2_nu = 0.3^2
                       m0 = 0
                       V0 = 1
                       rho1 = 0.9
                       
                       # Hyperparameters
                       c_sigma = 0.01
                       d_sigma = 0.01
                       a_r = 0.01
                       b_r = 0.01
                       beta = rbind(c(0, -0.6, 0, -0.7, 0, -0.5, 0), c(-0.4, 0, -0.4, 0, 0, 0, 0))
                       e = 1; f = 1; g = 1; h = 1
                       g_rho = g_rho_store[current_sim]
                       h_rho = h_rho_store[current_sim]
                       cutoff = 0
                       
                       # Covariates and latent states
                       S = run.mc.sim(A, num.iters = Ti)
                       Z = matrix(rnorm(Ti*p, 0, 1), nrow = Ti, ncol = p)
                       X = rep(NA, Ti)
                       X[1] = rnorm(1, m0, V0)
                       for(t in 2:Ti){
                         X[t] = rho1 * X[t-1] + rnorm(1, 0, sqrt(sigma2_nu))
                       }
                       psi = 1-1/(1+exp(X + lambda[S] + rowSums(Z * beta[S,])))
                       truemu = r[S] * psi / (1-psi)
                       Y = rnbinom(n = Ti, size = r[S], mu = truemu)
                       
                       tryCatch({
                         start_time = Sys.time()
                         results = NBSLDS(Z, Y, maxiter, burnin, J, cutoff,
                                          a_r, b_r, m0, V0, c_sigma, d_sigma, e, f, g, h,
                                          g_rho, h_rho)
                         end_time = Sys.time()
                         cat('NB MCMC time: ', end_time - start_time, '\n')
                         
                         post_xi = results[[1]]
                         post_zeta = results[[2]]
                         post_pi = results[[3]]
                         post_S = results[[4]]
                         post_r = results[[5]]
                         post_rho1 = results[[6]]
                         post_sigma2_nu = results[[7]]
                         post_gamma = results[[8]]
                         post_beta = results[[9]]
                         post_x = results[[10]]
                         num_switch = results[[11]]
                         ads_accept = results[[12]]
                         post_mu = results[[13]]
                         
                         time_store = end_time - start_time
                         
                         xi_m = mean(post_xi[burnin:maxiter])
                         zeta_m = mean(post_zeta[burnin:maxiter])
                         pi_m = rowMeans(post_pi[,burnin:maxiter])
                         r_m = rowMeans(post_r[,burnin:maxiter])
                         rho1_m = mean(post_rho1[burnin:maxiter])
                         nu_m = mean(post_sigma2_nu[burnin:maxiter])
                         mu_m = rowMeans(post_mu[,burnin:maxiter])
                         mu_mid = rowMedians(post_mu[,burnin:maxiter])
                         x_m = rowMeans(post_x[,burnin:maxiter])
                         ppi_mat = matrix(0, nrow = 2, ncol = p)
                         for(iter in burnin:maxiter){
                           ppi_mat = ppi_mat + post_gamma[,,iter]
                         }
                         ppi_mat = ppi_mat/length(burnin:maxiter)
                         gamma_m = 1*(ppi_mat > 0.5)
                         beta_m = matrix(0, nrow = 2, ncol = p+1)
                         templist = rep(NA, length(burnin:maxiter))
                         for(cp in 1:(p+1)){
                           for(k in 1:2){
                             for(iter in burnin:maxiter){
                               templist[iter] = post_beta[k,cp,iter]
                             }
                             templist[templist == 0] = NA
                             if(sum(!is.na(templist)) == 0){
                               templist = c(0, templist)
                             }
                             beta_m[k,cp] = mean(templist, na.rm = TRUE)
                             templist = rep(NA, length(burnin:maxiter))
                           }
                         }
                         S_post = apply(post_S, 1, which.max)
                         
                         list(Y, X, Z, truemu, S, 
                              time_store, xi_m, zeta_m, pi_m, S_post, 
                              r_m, rho1_m, nu_m, gamma_m, beta_m,
                              x_m, num_switch, ads_accept, mu_m)
                       }, error = function(e){cat("Error:", conditionMessage(e), "\n"); 0})
                     }

stopCluster(c1)
save.image(file = "Sim4_variable_selection_sensitivity_results.RData")

# Results -----------------------------------------------------------------

load("Sim4_variable_selection_sensitivity_results.RData")

maxiter = 20000
burnin = 10000
p = 7

goodinds = which(myresults[,12] != 0)
length(goodinds)

beta = rbind(c(0, -0.6, 0, -0.7, 0, -0.5, 0), c(-0.4, 0, -0.4, 0, 0, 0, 0))
trueppi = 1*(beta != 0)

latent = matrix(NA, nrow = length(goodinds), ncol = 7)
colnames(latent) = c('Acc','FNR', 'FPR', 'Prec','Sens','Spec','F1')
varsel = matrix(NA, nrow = length(goodinds), ncol = 7)
colnames(varsel) = c('Selected','FNR','FPR','Prec','Sens','Spec','F1')
l1_err = matrix(NA, nrow = length(goodinds), ncol = 2)
colnames(l1_err) = c('L1_x', 'L1_mu')

for(i in 1:length(goodinds)){
  num = goodinds[i]
  Y = myresults[num,1][[1]]
  Ti = length(Y)
  X = myresults[num,2][[1]]
  truemu = myresults[num,4][[1]]
  S = myresults[num,5][[1]]
  S_post = myresults[num,10][[1]]
  ppi = gamma_m = myresults[num,14][[1]]
  x_m = myresults[num,16][[1]]
  mu_m = myresults[num,19][[1]]

  l1_err[i,1] = mean(abs(X - x_m))
  l1_err[i,2] = mean(abs(truemu - mu_m))
  
  varsel[i,1] = sum(ppi)
  varsel[i,2] = sum((ppi == 0) & (trueppi == 1))/(sum((ppi == 0) & (trueppi == 1)) + sum((ppi == 1) & (trueppi == 1)))
  varsel[i,3] = sum((ppi == 1) & (trueppi == 0))/(sum((ppi == 1) & (trueppi == 0)) + sum((ppi == 0) & (trueppi == 0)))
  TP = sum((ppi == 1) & (trueppi == 1))
  FP = sum((ppi == 1) & (trueppi == 0))
  TN = sum((ppi == 0) & (trueppi == 0))
  FN = sum((ppi == 0) & (trueppi == 1))
  varsel[i,4] = prec = TP/(TP + FP)  # prec
  varsel[i,5] = sens = TP/(TP+FN)  # sens
  varsel[i,6] = spec = TN/(TN+FP)  # spec
  varsel[i,7] = 2*prec*sens/(prec+sens)  # f1
  
  TP = sum((S_post == 1) & (S == 1))
  FP = sum((S_post == 1) & (S == 2))
  TN = sum((S_post == 2) & (S == 2))
  FN = sum((S_post == 2) & (S == 1))
  latent[i,1] = mean(S_post == S)
  latent[i,2] = sum((S_post == 2) & (S == 1))/(sum((S_post == 2) & (S == 1)) + sum((S_post == 1) & (S == 1)))
  latent[i,3] = sum((S_post == 1) & (S == 2))/(sum((S_post == 1) & (S == 2)) + sum((S_post == 2) & (S == 2)))
  latent[i,4] = prec = TP/(TP+FP)  # prec
  latent[i,5] = sens = TP/(TP+FN)  # sens
  latent[i,6] = spec = TN/(TN+FP)  # spec
  latent[i,7] = 2*prec*sens/(prec+sens)  # f1
}


round(colMeans(varsel[1:20,]),2)  # Beta(1,1)
round(colMeans(varsel[25:44,]),2) # Beta(2,3)
round(colMeans(varsel[49:68,]),2) # Beta(1,2)
round(colMeans(varsel[73:92,]),2) # Beta(1,3)
round(colMeans(varsel[97:116,]),2) # Beta(1,5)

round(colMeans(latent[1:20,]),2)  # 1,1
round(colMeans(latent[25:44,]),2) # 2,3
round(colMeans(latent[49:68,]),2) # 1,2
round(colMeans(latent[73:92,]),2) # 1,3
round(colMeans(latent[97:116,]),2) # 1,5

round(colMeans(l1_err[1:20,]),2)  # 1,1
round(colMeans(l1_err[25:44,]),2) # 2,3
round(colMeans(l1_err[49:68,]),2) # 1,2
round(colMeans(l1_err[73:92,]),2) # 1,3
round(colMeans(l1_err[97:116,]),2) # 1,5