# This file reproduces the simulation study results using data generated with
# Student's t-distributed errors, corresponding to Appendix B.3 of the supplement.

# Simulation --------------------------------------------------------------

library(doSNOW)
library(parallel)
library(truncnorm)
library(BayesLogit)
library(mvtnorm)
library(MCMCpack)
library(knitr)
library(matrixStats)

c1 <- makeCluster(12)
registerDoSNOW(c1)
sims = 24
source('NBSLDS.R')

seed_store = 1:sims
myresults <- foreach(current_sim = 1:sims, .packages = c('doSNOW','truncnorm','BayesLogit','mvtnorm','MCMCpack'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE) %dopar% { 
                       
                       # Data generation
                       set.seed(seed_store[current_sim])
                       run.mc.sim <- function(A, num.iters = 50) {
                         num.states <- nrow(A)
                         states <- numeric(num.iters)
                         states[1] <- sample(1:2, 1, prob = c(0.5, 0.5))
                         for(t in 2:num.iters) {
                           p  <- A[states[t-1],]
                           states[t] <-  which(rmultinom(1, 1, p) == 1)
                         }
                         return(states)
                       }
                       
                       A = matrix(data = c(0.98, 0.02, 0.02, 0.98), byrow = TRUE, nrow = 2, ncol = 2)
                       Ti = 2000
                       p = 7
                       
                       # Parameters
                       maxiter = 20000
                       burnin = 10000
                       J = 10
                       r = c(2,5)
                       lambda = c(-1.5,-0.5)
                       sigma2_nu = 0.3^2
                       m0 = 0
                       V0 = 1
                       rho1 = 0.9
                       
                       # Hyperparameters
                       c_sigma = 0.01
                       d_sigma = 0.01
                       a_r = 0.01
                       b_r = 0.01
                       beta = rbind(c(0, -0.6, 0, -0.7, 0, -0.5, 0), c(-0.4, 0, -0.4, 0, 0, 0, 0))
                       e = 1; f = 1; g = 1; h = 1
                       g_rho = 1
                       h_rho = 2
                       cutoff = 0
                       
                       # Covariates and latent states
                       S = run.mc.sim(A, num.iters = Ti)
                       Z = matrix(rnorm(Ti*p, 0, 1), nrow = Ti, ncol = p)
                       X = rep(NA, Ti)
                       X[1] = rnorm(1, m0, V0)
                       for(t in 2:Ti){
                         X[t] = rho1 * X[t-1] + rt(1, 50)
                       }
                       psi = 1-1/(1+exp(X + lambda[S] + rowSums(Z * beta[S,])))
                       truemu = r[S] * psi / (1-psi)
                       Y = rnbinom(n = Ti, size = r[S], mu = truemu)
                       
                       tryCatch({
                         start_time = Sys.time()
                         results = NBSLDS(Z, Y, maxiter, burnin, J, cutoff,
                                          a_r, b_r, m0, V0, c_sigma, d_sigma, e, f, g, h,
                                          g_rho, h_rho)
                         end_time = Sys.time()
                         cat('NB MCMC time: ', end_time - start_time, '\n')
                         
                         post_xi = results[[1]]
                         post_zeta = results[[2]]
                         post_pi = results[[3]]
                         post_S = results[[4]]
                         post_r = results[[5]]
                         post_rho1 = results[[6]]
                         post_sigma2_nu = results[[7]]
                         post_gamma = results[[8]]
                         post_beta = results[[9]]
                         post_x = results[[10]]
                         num_switch = results[[11]]
                         ads_accept = results[[12]]
                         post_mu = results[[13]]
                         
                         time_store = end_time - start_time
                         
                         list(Y, X, Z, truemu, S, 
                              time_store, post_xi, post_zeta, post_pi, post_S, 
                              post_r, post_rho1, post_sigma2_nu, post_gamma, post_beta,
                              post_x, num_switch, ads_accept, post_mu)
                       }, error = function(e){cat("Error:", conditionMessage(e), "\n"); 0})
                     }

stopCluster(c1)
save.image(file = "Sim3_Student_t_errors_results.RData")

# Results -----------------------------------------------------------------

load("Sim3_Student_t_errors_results.RData")

maxiter = 20000
burnin = 10000
p = 7
maxiter_store = rep(0, sims)
for(num in 1:sims){
  if(myresults[num,6] != 0){
    post_xi = myresults[num,7][[1]]
    maxiter_store[num] = tail(which(!is.na(post_xi)), 1)
  }
}
goodinds = which(maxiter_store == maxiter)[1:20]
length(goodinds)

l1err_store = matrix(NA, nrow = length(goodinds), ncol = 2)
post_mean_store = matrix(NA, nrow = length(goodinds), ncol = 7)
colnames(post_mean_store) = c('r1','r2','rho1','sigma2','xi','zeta','pi')
beta_m = array(NA, dim = c(2,8,length(goodinds)))
beta_l = array(NA, dim = c(2,8,length(goodinds)))
beta_h = array(NA, dim = c(2,8,length(goodinds)))
lambda = c(-1.5,-0.5)
beta = rbind(c(0, -0.6, 0, -0.7, 0, -0.5, 0), c(-0.4, 0, -0.4, 0, 0, 0, 0))
r = c(2,5)
sigma2_nu = 0.3^2
rho1 = 0.9
trueppi = 1*(beta != 0)
latent = matrix(NA, nrow = length(goodinds), ncol = 7)
colnames(latent) = c('Acc','FNR', 'FPR', 'Prec','Sens','Spec','F1')
varsel = matrix(NA, nrow = length(goodinds), ncol = 7)
colnames(varsel) = c('Selected','FNR','FPR','Prec','Sens','Spec','F1')
CI = matrix(NA, nrow = length(goodinds), ncol = 4)
colnames(CI) = c('%_coverage_x','%_coverage_mu','width_x','width_mu')

r1_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
r2_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
rho1_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
sigma2_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
xi_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
zeta_ci = matrix(NA, nrow = length(goodinds), ncol = 2)
pi_ci = matrix(NA, nrow = length(goodinds), ncol = 2)

for(i in 1:length(goodinds)){
  num = goodinds[i]
  Y = myresults[num,1][[1]]
  Ti = length(Y)
  X = myresults[num,2][[1]]
  Z = myresults[num,3][[1]]
  Z1 = cbind(1,Z)
  truemu = myresults[num,4][[1]]
  S = myresults[num,5][[1]]
  time_store = myresults[num,6][[1]]
  post_xi = myresults[num,7][[1]]
  post_zeta = myresults[num,8][[1]]
  post_pi = myresults[num,9][[1]]
  post_S = myresults[num,10][[1]]
  post_r = myresults[num,11][[1]]
  post_rho1 = myresults[num,12][[1]]
  post_sigma2_nu = myresults[num,13][[1]]
  post_gamma = myresults[num,14][[1]]
  post_beta = myresults[num,15][[1]]
  post_x = myresults[num,16][[1]]
  num_switch = myresults[num,17][[1]]
  ads_accept = myresults[num,18][[1]]
  post_mu = myresults[num,19][[1]]
  
  temp_m = rowMeans(post_x[,burnin:maxiter])
  temp_l = rowQuantiles(post_x[,burnin:maxiter], probs = 0.025)
  temp_h = rowQuantiles(post_x[,burnin:maxiter], probs = 0.975)
  
  for(cp in 1:(p+1)){
    for(kprime in 1:2){
      beta_m[kprime,cp,i] = mean(post_beta[kprime,cp,burnin:maxiter][post_beta[kprime,cp,burnin:maxiter] != 0])
      beta_l[kprime,cp,i] = quantile(post_beta[kprime,cp,burnin:maxiter][post_beta[kprime,cp,burnin:maxiter] != 0], prob = 0.025)
      beta_h[kprime,cp,i] = quantile(post_beta[kprime,cp,burnin:maxiter][post_beta[kprime,cp,burnin:maxiter] != 0], prob = 0.975)
    }
  }
  S_post = apply(post_S, 1, which.max)
  psi_m = 1-1/(1+exp(temp_m + rowSums(Z1 * beta_m[S_post,,i])))
  psi_l = 1-1/(1+exp(temp_l + rowSums(Z1 * beta_l[S_post,,i])))
  psi_h = 1-1/(1+exp(temp_h + rowSums(Z1 * beta_h[S_post,,i])))
  mean_m = rowMeans(post_r[,burnin:maxiter])[S_post] * psi_m / (1-psi_m)
  mean_l = rowQuantiles(post_r[,burnin:maxiter], probs = 0.025)[S_post] * psi_l / (1-psi_l)
  mean_h = rowQuantiles(post_r[,burnin:maxiter], probs = 0.975)[S_post] * psi_h / (1-psi_h)
  
  l1err_store[i,1] = mean(abs(X - temp_m))
  l1err_store[i,2] = mean(abs(truemu - mean_m))
  
  post_mean_store[i,1] = mean(post_r[1,burnin:maxiter])
  post_mean_store[i,2] = mean(post_r[2,burnin:maxiter])
  post_mean_store[i,3] = mean(post_rho1[burnin:maxiter])
  post_mean_store[i,4] = mean(post_sigma2_nu[burnin:maxiter])
  post_mean_store[i,5] = mean(post_xi[burnin:maxiter])
  post_mean_store[i,6] = mean(post_zeta[burnin:maxiter])
  post_mean_store[i,7] = mean(post_pi[2,burnin:maxiter])
  
  r1_ci[i,] = quantile(post_r[1,burnin:maxiter], probs = c(0.025, 0.975))
  r2_ci[i,] = quantile(post_r[2,burnin:maxiter], probs = c(0.025, 0.975))
  rho1_ci[i,] = quantile(post_rho1[burnin:maxiter], probs = c(0.025, 0.975))
  sigma2_ci[i,] = quantile(post_sigma2_nu[burnin:maxiter], probs = c(0.025, 0.975))
  xi_ci[i,] = quantile(post_xi[burnin:maxiter], probs = c(0.025, 0.975))
  zeta_ci[i,] = quantile(post_zeta[burnin:maxiter], probs = c(0.025, 0.975))
  pi_ci[i,] = quantile(post_pi[2,burnin:maxiter], probs = c(0.025, 0.975))
  
  CI[i,1] = mean(sapply(1:Ti, function(x) between(X[x], temp_l[x], temp_h[x])))
  CI[i,2] = mean(sapply(1:Ti, function(x) between(truemu[x], mean_l[x], mean_h[x])))
  CI[i,3] = mean(abs(temp_h - temp_l))
  CI[i,4] = mean(abs(mean_h - mean_l))
  
  ppi_mat = matrix(0, nrow = 2, ncol = 7)
  for(iter in burnin:maxiter){
    ppi_mat = ppi_mat + post_gamma[,,iter]
  }
  ppi_mat = ppi_mat/length(burnin:maxiter)
  ppi = 1*(ppi_mat >= 0.5)
  
  varsel[i,1] = sum(ppi)
  varsel[i,2] = sum((ppi == 0) & (trueppi == 1))/(sum((ppi == 0) & (trueppi == 1)) + sum((ppi == 1) & (trueppi == 1)))
  varsel[i,3] = sum((ppi == 1) & (trueppi == 0))/(sum((ppi == 1) & (trueppi == 0)) + sum((ppi == 0) & (trueppi == 0)))
  TP = sum((ppi == 1) & (trueppi == 1))
  FP = sum((ppi == 1) & (trueppi == 0))
  TN = sum((ppi == 0) & (trueppi == 0))
  FN = sum((ppi == 0) & (trueppi == 1))
  varsel[i,4] = prec = TP/(TP + FP)  # prec
  varsel[i,5] = sens = TP/(TP+FN)  # sens
  varsel[i,6] = spec = TN/(TN+FP)  # spec
  varsel[i,7] = 2*prec*sens/(prec+sens)  # f1
  
  TP = sum((S_post == 1) & (S == 1))
  FP = sum((S_post == 1) & (S == 2))
  TN = sum((S_post == 2) & (S == 2))
  FN = sum((S_post == 2) & (S == 1))
  latent[i,1] = mean(S_post == S)
  latent[i,2] = sum((S_post == 2) & (S == 1))/(sum((S_post == 2) & (S == 1)) + sum((S_post == 1) & (S == 1)))
  latent[i,3] = sum((S_post == 1) & (S == 2))/(sum((S_post == 1) & (S == 2)) + sum((S_post == 2) & (S == 2)))
  latent[i,4] = prec = TP/(TP+FP)  # prec
  latent[i,5] = sens = TP/(TP+FN)  # sens
  latent[i,6] = spec = TN/(TN+FP)  # spec
  latent[i,7] = 2*prec*sens/(prec+sens)  # f1
}

# RMSE
r1_mse = 1/length(goodinds) * sum((post_mean_store[,1] - r[1])^2, na.rm = TRUE)
r2_mse = 1/length(goodinds) * sum((post_mean_store[,2] - r[2])^2, na.rm = TRUE)
rho1_mse = 1/length(goodinds) * sum((post_mean_store[,3] - rho1)^2, na.rm = TRUE)
nu_mse = 1/length(goodinds) * sum((post_mean_store[,4] - sigma2_nu)^2, na.rm = TRUE)
xi_mse = 1/length(goodinds) * sum((post_mean_store[,5] - 0.98)^2, na.rm = TRUE)
zeta_mse = 1/length(goodinds) * sum((post_mean_store[,6] - 0.98)^2, na.rm = TRUE)
pi_mse = 1/length(goodinds) * sum((post_mean_store[,7] - 0.5)^2, na.rm = TRUE)

beta_mse = matrix(0, nrow = 2, ncol = p+1)
truebeta = cbind(lambda, beta)
for(k in 1:2){
  for(cp in 1:(p+1)){
    beta_mse[k,cp] = 1/length(goodinds) * sum((beta_m[k,cp,] - truebeta[k,cp])^2)
  }
}

# Create table
library(knitr)
tab = data.frame("Param" = c("Dispersion r1", "Dispersion r2", "Discount factor rho1", "sigma2_nu",
                             "xi", "zeta", "pi", "Label switches","L1 error (x)", "L1 error (mu)", "Compute time (hrs)"),
                 "True param." = c(r[1], r[2], rho1, sigma2_nu, 0.98, 0.98, 0.5, "-", "-", "-", "-"),
                 "Post mean" = round(c(mean(post_mean_store[,1], na.rm = TRUE), mean(post_mean_store[,2], na.rm = TRUE),
                                       mean(post_mean_store[,3], na.rm = TRUE), mean(post_mean_store[,4], na.rm = TRUE),
                                       mean(post_mean_store[,5], na.rm = TRUE), mean(post_mean_store[,6], na.rm = TRUE),
                                       mean(post_mean_store[,7], na.rm = TRUE),
                                       mean(unlist(myresults[goodinds,17])),
                                       mean(l1err_store[,1], na.rm = TRUE), mean(l1err_store[,2], na.rm = TRUE),
                                       mean(unlist(as.data.frame(myresults[goodinds,6])))),3),
                 "SD" = round(c(sd(post_mean_store[,1], na.rm = TRUE), sd(post_mean_store[,2], na.rm = TRUE),
                                sd(post_mean_store[,3], na.rm = TRUE), sd(post_mean_store[,4], na.rm = TRUE),
                                sd(post_mean_store[,5], na.rm = TRUE), sd(post_mean_store[,6], na.rm = TRUE),
                                sd(post_mean_store[,7], na.rm = TRUE),
                                sd(unlist(myresults[goodinds,17])),
                                sd(l1err_store[,1], na.rm = TRUE), sd(l1err_store[,2], na.rm = TRUE),
                                sd(unlist(as.data.frame(myresults[goodinds,6])))),2),
                 "CI_l" = round(c(mean(r1_ci[,1]), mean(r2_ci[,1]), mean(rho1_ci[,1]), mean(sigma2_ci[,1]),
                                  mean(xi_ci[,1]), mean(zeta_ci[,1]), mean(pi_ci[,1]), 0, 0, 0, 0), 2),
                 "CI_h" = round(c(mean(r1_ci[,2]), mean(r2_ci[,2]), mean(rho1_ci[,2]), mean(sigma2_ci[,2]),
                                  mean(xi_ci[,2]), mean(zeta_ci[,2]), mean(pi_ci[,2]), 0, 0, 0, 0), 2),
                 "RMSE" = round(sqrt(c(r1_mse, r2_mse, rho1_mse, nu_mse, xi_mse, zeta_mse, pi_mse, 0, 0, 0, 0)),2))
kable(tab, format = "latex", booktabs = T)

# Create beta table
tab1 = data.frame("Param" = c("lambda","beta1","beta2","beta3","beta4","beta5","beta6","beta7"),
                  "True param." = truebeta[1,],
                  "Post mean" = round(rowMeans(beta_m[1,,]),3),
                  "SD" = round(apply(beta_m[1,,], 1, sd),2),
                  "CI_l" = round(rowMeans(beta_l[1,,]),2),
                  "CI_h" = round(rowMeans(beta_h[1,,]),2),
                  "RMSE" = round(sqrt(beta_mse[1,]),2))
kable(tab1, format = "latex", booktabs = T)

tab2 = data.frame("Param" = c("lambda","beta1","beta2","beta3","beta4","beta5","beta6","beta7"),
                  "True param." = truebeta[2,],
                  "Post mean" = round(rowMeans(beta_m[2,,]),3),
                  "SD" = round(apply(beta_m[2,,], 1, sd),2),
                  "CI_l" = round(rowMeans(beta_l[2,,]),2),
                  "CI_h" = round(rowMeans(beta_h[2,,]),2),
                  "RMSE" = round(sqrt(beta_mse[2,]),2))
kable(tab2, format = "latex", booktabs = T)

colMeans(varsel)
colMeans(latent)

# CI coverage
colMeans(CI)
colSds(CI)