# NBSLDS

Source code accompanying the paper "A Bayesian Switching Linear Dynamical System for Estimating Seizure Chronotypes" by Wang et al.
NBSLDS is a state-space model which can be used to fit and forecast seizure generating processes. 
This folder contains code to replicate all simulation studies. Please see below for instructions on how to run the simulations.

## Instructions for decrypting source files

To request the decryption password, please complete the request form at https://forms.gle/rUzirB2K75VQqtfh6.
Install the R package `encryptr`. 
Run the code in `source_file_decryption.R` to decrypt all source files.
When prompted, enter the decryption password. 

## Instructions

The R packages required for running each simulation are listed at the top of the files.
Below are descriptions of the files, including the location of the relevant results in the main text or supplement. 

1. Sim_1_base_model_simulations.R -- Appendix B.1, simulations using data generated from the NBSLDS model
2. Sim_2_Poisson.R -- Appendix B.2, simulations using Poisson data
3. Sim_3_Student_t_errors.R -- Appendix B.3, simulations using data generated with t-distributed errors
4. Sim_4_variable_selection_sensitivity.R -- Appendix B.4, sensitivity of beta prior on variable selection
5. NBSLDS.R -- contains the function to run the model.

### Authors  

Emily T. Wang, Marina Vannucci, Zulfi Haneef, Robert Moss, Vikram R. Rao, and Sharon Chiang